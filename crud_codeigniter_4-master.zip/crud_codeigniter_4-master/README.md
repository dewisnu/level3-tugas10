# Tutorial CRUD di CodeIgniter 4

[![Build Status](https://travis-ci.org/codeigniter4/CodeIgniter4.svg?branch=develop)](https://travis-ci.org/codeigniter4/CodeIgniter4)
[![Coverage Status](https://coveralls.io/repos/github/codeigniter4/CodeIgniter4/badge.svg?branch=develop)](https://coveralls.io/github/codeigniter4/CodeIgniter4?branch=develop)
<br>

## Deskripsi Project

Inilah tutorial lengkap membuat fitur crud menggunakan codeigniter 4. Di tutorial ini dijelaskan secara detail dan step by step. Baca selengkapnya di >> https://ilmucoding.com/tutorial-crud-codeigniter-4/
